using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour {
	void Update() {
		if (Input.anyKeyDown) {
			SceneManager.LoadScene(1);
		}
	}
}